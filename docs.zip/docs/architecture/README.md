# Architecture

## Purpose

The Architecture documentation describes how DiaperScout is implemented.

Where the Product Specification defines what the Guide is, and the Community documentation defines how the Guide grows, the Architecture documentation defines how software brings those ideas to life.

The architecture exists to bring the idea of the Atlas to life.

It is intentionally technology-agnostic wherever possible. These documents describe the structure, behaviour and principles of the system rather than prescribing specific implementation technologies.

## Relationship to the Product

The Product Specification is the authoritative description of DiaperScout.

The architecture exists to implement that specification faithfully.

If implementation becomes difficult, the preferred solution is to improve the architecture rather than weaken the product vision.

## Guiding Philosophy

DiaperScout is not simply a database.

It is an Explorer's Guide.

The application is one way to experience that Guide.

The architecture therefore exists to:

- preserve trustworthy knowledge;
- model the real world faithfully;
- support exploration;
- protect the integrity of the Guide;
- make future evolution straightforward.

## Principles

The detailed principles are documented in:

- Architecture Principles

Those principles should be understood before reading the remaining architecture documents.

## Documentation Structure

This section contains:

| Document | Purpose |
|----------|---------|
| Architecture Principles | Core architectural philosophy |
| Knowledge Architecture | How knowledge flows through the system |
| Domain Model | Core business entities and relationships |
| Backend Services | Logical backend services |
| API Architecture | Public API design principles |
| Database Model | Persistent storage model |
| Search | Product discovery and indexing |
| Synchronisation | Offline and background synchronisation |
| Media and Evidence | Images and supporting evidence |
| Authentication and Roles | Users, permissions and trust |
| Moderation | Editorial workflow |
| Scout Task System | Community-driven maintenance of the Guide |
| Deployment and Operations | Operational architecture |

## Scope

These documents intentionally focus on architecture rather than implementation.

Technology selections are recorded separately through Architecture Decision Records (ADRs) as the project evolves.