# API Architecture

## Purpose

This document defines the architectural principles governing the DiaperScout API.

The API is the public interface to the Atlas.

Every official application, including the Progressive Web App (PWA), consumes the same API.

The API should expose the capabilities of the Atlas rather than the structure of the underlying database.

---

# API Philosophy

DiaperScout is an API-first architecture.

The official PWA is not a privileged client.

Every client communicates with the backend through the same published interface.

Examples include:

- Progressive Web App
- Future native mobile applications
- Desktop applications
- Administrative tools
- Automated testing

Business rules should exist once within the backend rather than being duplicated across clients.

---

# Design Principles

The API should be:

- predictable;
- deterministic;
- versioned;
- discoverable;
- self-documenting;
- secure;
- stable within supported versions.

Clients should be able to understand how to interact with the Atlas without requiring implementation knowledge.

---

# Resource-Oriented Design

The API should expose domain concepts rather than database tables.

Examples include:

- Products
- Manufacturers
- Retailers
- Observations
- Scout Tasks

Resources should represent meaningful concepts within DiaperScout.

Implementation details should remain hidden.

---

# Atlas-Centred

The API exposes the Atlas.

Most requests should retrieve canonical knowledge.

Examples include:

- Product pages
- Product Specifications
- Manufacturer information
- Retail availability summaries

Raw observations should only be exposed where appropriate.

The Atlas remains the primary public representation of knowledge.

---

# Evidence Submission

Community contributions enter the system as observations.

Examples include:

- Product discovery
- Retail observation
- Correction request
- Manufacturer submission

Submitting evidence does not immediately change the Atlas.

Instead, evidence enters the editorial workflow.

The API should clearly communicate this distinction.

---

# Long-Running Operations

Some requests initiate workflows rather than completing immediately.

Examples include:

- Product discovery
- Image processing
- Large media uploads

The API should acknowledge successful submission as soon as evidence has been safely recorded.

Subsequent processing should expose observable progress.

Clients should never be left uncertain whether work has been received.

---

# Progress Reporting

Long-running operations should expose meaningful progress.

Examples include:

- Discovery received
- Images processed
- Barcode validated
- Ready for moderation
- Published

Progress should describe meaningful milestones rather than low-level technical operations.

---

# Versioning

The API should support explicit versioning.

Breaking changes should be introduced through new API versions.

Supported versions should remain stable.

Older versions may eventually be retired following an appropriate deprecation period.

---

# Authentication

Authentication establishes identity.

Authorisation determines responsibility.

Authentication should remain independent of business logic.

The API should consistently enforce permissions regardless of client.

---

# Error Handling

Errors should be:

- consistent;
- descriptive;
- actionable.

Clients should understand:

- what happened;
- why it happened;
- how to resolve it where possible.

Unexpected failures should never expose internal implementation details.

---

# Idempotency

Operations should behave predictably when repeated.

Where practical, repeated submissions should not create unintended duplicate data.

This is particularly important for:

- barcode scanning;
- observation submission;
- media uploads.

---

# Pagination and Filtering

Large collections should support efficient retrieval.

Filtering should use structured attributes wherever possible.

Free-text search should remain focused on product names.

Attribute-based exploration should use deterministic filters.

---

# API Evolution

The API should evolve alongside the Atlas.

Future additions should extend existing capabilities where practical.

Clients should be able to adopt new functionality incrementally without unnecessary disruption.

---

# Self-Documentation

The API should be understandable without reference to backend implementation.

Resource names, request structures and responses should reflect the language of the Atlas.

Developers should work with concepts such as:

- Products
- Observations
- Evidence
- Editorial Decisions

rather than internal database structures.

---

# Architectural Consequences

This architecture results in several important characteristics.

- Every client consumes the same API.
- Business rules exist only within backend services.
- The API exposes canonical knowledge rather than implementation details.
- Evidence enters through consistent editorial workflows.
- Long-running work exposes observable progress.
- The API remains understandable because it reflects the domain model rather than the database.