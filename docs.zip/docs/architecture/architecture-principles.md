# Architecture Principles

## Purpose

This document defines the architectural principles that guide every technical decision within DiaperScout.

It does not describe specific technologies, programming languages or deployment strategies.

Instead, it describes the philosophy that the architecture exists to support.

Whenever multiple technical solutions are possible, the option that best aligns with these principles should normally be preferred.

---

# The Atlas Comes First

The architecture exists to bring the idea of the Atlas to life.

Everything else exists to support that objective.

The application is not the product.

The Atlas is the product.

The architecture should therefore preserve the Atlas independently of any individual application, website or client.

---

# Architecture Serves the Product

The Product Specification defines what DiaperScout is.

The architecture exists to implement that specification faithfully.

If implementation becomes difficult, the preferred solution is to improve the architecture rather than compromise the product vision.

---

# Model the Real World

The domain model should represent the real world as closely as practical.

Entities should exist because they represent real concepts, not because they simplify implementation.

For example:

- Products are independent of retailers.
- Retailers stock products.
- Scouts make observations.
- Manufacturers provide specifications.
- Moderators curate the Guide.

The database should reflect reality rather than application convenience.

---

# Knowledge is Built from Evidence

The Guide is not edited directly.

It is built from evidence.

Evidence may originate from:

- Scout discoveries;
- Community observations;
- Manufacturer submissions;
- Correction requests;
- Moderator investigations.

The Guide is the curated interpretation of that evidence.

---

# One Editorial Pipeline

All knowledge enters the Guide through a consistent editorial workflow.

The source of information affects its authority, but not the architectural process.

Whether information originates from:

- a Scout;
- a Manufacturer;
- a Moderator;

it should enter the system as evidence before becoming part of the Guide.

There should never be multiple competing mechanisms for modifying canonical knowledge.

---

# Canonical Knowledge and Observations are Different

The Guide represents canonical knowledge.

Observations represent evidence.

These concepts should remain architecturally separate.

For example:

- Product Specifications belong to the Guide.
- Retail sightings belong to observations.
- Discovery photographs belong to observations.
- Manufacturer images belong to products.

Keeping these concepts separate improves integrity, traceability and maintainability.

---

# Deterministic Over Intelligent

Where behaviour can be implemented using deterministic rules, deterministic rules should be preferred.

Search, filtering, moderation workflows and Guide construction should be understandable, explainable and reproducible.

Artificial intelligence may assist contributors in the future, but it should not replace structured knowledge or deterministic behaviour.

---

# Explainable Knowledge

Every significant fact recorded within the Guide should be traceable.

The architecture should be capable of explaining:

- why something is believed;
- where the information originated;
- who reviewed it;
- when it became part of the Guide.

Trust is strengthened when knowledge can explain itself.

---

# Preserve Knowledge

The Guide represents accumulated knowledge.

Knowledge should not be discarded unnecessarily.

Editorial history, observations and supporting evidence form part of the long-term value of the Atlas.

Backups exist primarily to preserve the Guide and its supporting evidence rather than merely protecting software.

---

# Progressive Trust

Responsibility should be earned.

Community members gain trust through consistently positive contributions.

Greater responsibility should come through demonstrated stewardship of the Guide rather than administrative assignment alone.

The system may recommend trusted contributors for additional responsibilities, but people make the final decisions.

---

# Continuous Evolution

The Guide is continuously evolving.

The architecture should support gradual evolution without relying upon scheduled maintenance windows.

Background processing should react to events as they occur.

Schema evolution should favour backwards-compatible changes wherever practical.

---

# API First

The API represents the public interface of DiaperScout.

Every client should consume the same API, including the official PWA.

Business rules should exist once within the backend rather than being duplicated across clients.

---

# Self-Documenting Systems

The architecture should favour clarity.

Names, identifiers, APIs and domain concepts should be understandable without requiring specialist knowledge.

Future contributors should be able to understand why the system exists before understanding how it is implemented.

---

# Simplicity Before Abstraction

Architecture should model today's domain accurately.

Future flexibility is valuable, but speculative complexity should be avoided.

The architecture should evolve naturally as the Guide evolves.

---

# The Long View

Architectural decisions should consider the long-term health of the project.

When multiple technically correct solutions exist, preference should normally be given to the one that:

- preserves knowledge;
- improves maintainability;
- strengthens trust;
- simplifies future evolution;
- protects the integrity of the Atlas.

The architecture should still make sense to future contributors many years after it was originally written.