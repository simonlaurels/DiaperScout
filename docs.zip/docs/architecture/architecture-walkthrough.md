# Architecture Walkthrough

## Purpose

This document demonstrates how the DiaperScout architecture works by following a real-world example.

Rather than describing individual components in isolation, it shows how the Atlas, community and architecture work together to transform an observation into trusted knowledge.

The walkthrough is illustrative rather than exhaustive.

Its purpose is to explain how the architecture thinks.

---

# Scenario

A Scout visits a supermarket.

They notice a product that does not yet exist within the Atlas.

The barcode is scanned.

The Atlas does not recognise it.

A discovery begins.

---

# Step 1 — Observation

The Scout records what they have observed.

They provide:

- barcode
- front photograph
- retailer
- GPS location
- optional price

At this stage nothing has changed within the Atlas.

The Scout has simply created an Observation.

---

# Step 2 — Evidence

The Observation is safely recorded.

Supporting evidence is attached to it.

Examples include:

- barcode photograph
- front photograph
- timestamp
- retailer
- location

The evidence belongs to the Observation.

It does not yet belong to the Product because no Product exists.

---

# Step 3 — Workflow

The workflow begins.

Background processing performs tasks such as:

- validating uploads;
- processing media;
- verifying the barcode;
- generating thumbnails.

The Scout can see meaningful progress throughout the process.

The contribution is already safe.

The remaining work is simply processing.

---

# Step 4 — Editorial Review

The Observation enters the editorial workflow.

A moderator reviews:

- the submitted evidence;
- product identity;
- supporting information.

Additional evidence may be requested.

The moderator is reviewing evidence rather than editing the Atlas directly.

---

# Step 5 — Editorial Decision

The moderator reaches a decision.

If accepted:

- a Product is created;
- a Product Specification is established;
- manufacturer information is recorded;
- canonical images are assigned where appropriate.

If rejected:

The Observation remains part of the historical record.

The Atlas remains unchanged.

---

# Step 6 — Atlas Updated

The Atlas now contains a new Product.

Users can:

- browse it;
- search for it;
- scan its barcode;
- discover where it has been observed.

The Atlas has grown.

---

# Step 7 — Supporting Systems

Publishing the Product causes other architectural components to respond.

Examples include:

- Search indexes updated.
- Scout trust recalculated.
- Notifications generated where appropriate.
- Scout Tasks evaluated.

These actions occur automatically through event-driven workflows.

---

# Step 8 — Future Refinement

Several months later a verified manufacturer submits an updated Product Specification.

This does not directly edit the Atlas.

Instead:

Manufacturer Observation

↓

Editorial Review

↓

Atlas Updated

The same editorial pipeline is followed regardless of who supplied the evidence.

---

# Step 9 — Continuing Exploration

Months later the Atlas notices the product has not been observed at a retailer for over ninety days.

Rather than assuming the information is still correct, it creates a Scout Task.

A nearby Scout confirms the product is still stocked.

The Atlas remains current because the community continues exploring.

---

# The Big Picture

Every subsystem described throughout the architecture contributes to a single objective.

Observations become evidence.

Evidence becomes trusted knowledge.

Trusted knowledge becomes the Atlas.

The Atlas guides future exploration.

Exploration generates new observations.

This cycle continues indefinitely.

```text
Scout

↓

Observation

↓

Evidence
