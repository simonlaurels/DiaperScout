# Authentication & Roles

## Purpose

This document describes how DiaperScout identifies users and assigns responsibility within the Atlas.

Authentication establishes identity.

Roles define responsibility.

Permissions exist to protect the integrity of the Atlas rather than to create hierarchy.

---

# Philosophy

DiaperScout is a community built around stewardship.

Greater responsibility is earned through positive contribution rather than granted automatically.

The architecture should encourage trust while protecting the Atlas from accidental or malicious changes.

---

# Authentication

Authentication answers one question:

> **Who is this contributor?**

The authentication system should provide:

- secure sign-in;
- secure session management;
- account recovery;
- identity verification where appropriate.

Authentication should remain independent of business logic.

---

# Authorisation

Authorisation answers a different question:

> **What responsibilities does this contributor have?**

Permissions should reflect responsibility rather than status.

---

# Roles

## Visitor

A visitor may:

- browse the Atlas;
- search products;
- explore retailers;
- scan recognised products.

Visitors cannot contribute evidence.

---

## Scout

A Scout contributes to the Atlas.

Responsibilities include:

- discovering products;
- submitting retailer observations;
- reporting corrections;
- completing Scout Tasks.

Scouts improve the Atlas through evidence.

They do not modify canonical knowledge directly.

---

## Trusted Scout

Trusted Scouts have demonstrated consistent, high-quality contributions.

Trust influences:

- editorial confidence;
- recommendation for moderator promotion;
- future community responsibilities.

Trusted Scout is recognition of stewardship rather than authority.

---

## Moderator

Moderators curate the Atlas.

Responsibilities include:

- reviewing observations;
- evaluating evidence;
- publishing canonical knowledge;
- maintaining editorial consistency;
- protecting the integrity of the Guide.

Moderators do not possess unrestricted administrative authority.

---

## Administrator

Administrators maintain the DiaperScout platform.

Responsibilities include:

- infrastructure;
- deployments;
- storage;
- security;
- configuration;
- moderator management;
- verified manufacturer management.

Administrators are responsible for the platform rather than the editorial content of the Atlas.

Administrative authority should remain separate from editorial authority wherever practical.

---

## Verified Manufacturer

Verified Manufacturers contribute official observations.

Examples include:

- product specifications;
- official imagery;
- product announcements.

Manufacturer observations enter the same editorial workflow as every other contribution.

Verification establishes identity rather than editorial authority.

---

# Trust

Trust reflects the quality and consistency of a contributor's work.

Trust should increase through:

- accepted observations;
- accurate discoveries;
- successful Scout Tasks;
- constructive participation.

Trust should decrease through:

- rejected evidence;
- malicious behaviour;
- repeated low-quality submissions.

Trust represents long-term stewardship rather than popularity.

---

# Promotion

Responsibility should normally be earned.

The architecture may recommend contributors for promotion when they demonstrate sustained, high-quality stewardship of the Atlas.

Promotion remains a human decision.

The contributor should be free to decline additional responsibility.

---

# Suspension

Where necessary, contributors may be suspended.

Suspension protects the Atlas from:

- malicious activity;
- persistent low-quality contributions;
- abuse of community systems.

Suspension should be proportionate and, where appropriate, reversible.

The objective is to protect the Atlas while allowing contributors the opportunity to rebuild trust.

---

# Principle of Least Privilege

Contributors should possess only the permissions required to fulfil their responsibilities.

Additional permissions should be granted deliberately and transparently.

Reducing unnecessary privilege reduces accidental mistakes and improves the long-term security of the Atlas.

---

# Separation of Responsibility

Editorial responsibility and operational responsibility should remain distinct.

Moderators curate knowledge.

Administrators maintain the platform.

Neither role should automatically imply the other.

---

# Evolution

As the community grows, new responsibilities may emerge.

Future roles should extend this model rather than replacing it.

The architecture should continue to encourage stewardship, transparency and earned responsibility.

The objective is not simply to manage permissions.

The objective is to cultivate a community capable of maintaining a trustworthy Atlas for many years to come.