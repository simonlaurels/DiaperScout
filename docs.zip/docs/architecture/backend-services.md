# Backend Services

## Purpose

This document describes the logical backend services that collectively implement DiaperScout.

These services define architectural responsibilities rather than deployment units.

A service may initially be implemented within a single application while remaining logically independent.

As DiaperScout evolves, individual services may be separated without fundamentally changing the architecture.

The services described here exist to bring the Atlas to life.

---

# Design Principles

Backend services should:

- have a single, well-defined responsibility;
- communicate through stable interfaces;
- remain independent of presentation technologies;
- support event-driven processing;
- preserve the integrity of the Atlas;
- model the real world rather than implementation convenience.

The service boundaries described in this document should remain stable even if implementation technologies change.

---

# Atlas Service

## Responsibility

Maintains the published Atlas.

Responsible for:

- Products
- Product Specifications
- Manufacturers
- Regional Variations
- Canonical Product Images

The Atlas Service represents DiaperScout's current understanding of the world.

It exposes canonical knowledge for browsing, searching and API consumption.

The Atlas Service never accepts direct community edits.

Its state changes only through accepted editorial decisions.

---

# Observation Service

## Responsibility

Records evidence submitted by the community.

Responsible for:

- Product discoveries
- Retail observations
- Correction requests
- Manufacturer submissions
- Barcode submissions

The Observation Service validates submissions before recording them.

Observations are immutable records of evidence.

They never directly modify the Atlas.

---

# Editorial Service

## Responsibility

Curates evidence into trusted knowledge.

Responsible for:

- moderation;
- review;
- approval;
- rejection;
- provenance;
- editorial history.

The Editorial Service is the only service capable of publishing changes to the Atlas.

Regardless of where evidence originates, every change follows the same editorial pipeline.

---

# Scout Service

## Responsibility

Supports the Scout community.

Responsible for:

- Scout Tasks
- Trust calculation
- Contribution history
- Promotion recommendations

The Scout Service encourages exploration and helps keep the Atlas current.

It does not directly modify canonical knowledge.

---

# Retail Service

## Responsibility

Maintains retailer information.

Responsible for:

- Retailers
- Countries
- Locations
- Shipping destinations
- Retailer metadata

Retail availability is not stored directly.

Instead, it is derived from community observations and editorial interpretation.

---

# Search Service

## Responsibility

Provides deterministic product discovery.

Responsible for:

- Product name search
- Structured filtering
- Search indexing

Search indexes canonical Atlas knowledge.

Search should remain deterministic, explainable and independent of artificial intelligence.

---

# Media Service

## Responsibility

Stores and processes media.

Responsible for:

- Canonical product images
- Observation evidence
- Image optimisation
- Thumbnail generation
- Media integrity

Media attached to the Atlas remains separate from evidence attached to observations.

---

# Notification Service

## Responsibility

Communicates meaningful events.

Notifications should be generated only in response to significant user actions.

Examples include:

- discovery accepted;
- additional evidence requested;
- correction request resolved;
- moderator invitation.

Routine community activity should remain discoverable within the application rather than generating notifications.

---

# Authentication Service

## Responsibility

Identifies users and manages access.

Responsible for:

- Authentication
- Sessions
- Roles
- Permissions
- Verified manufacturers

Authentication establishes identity.

Authorisation determines responsibility.

---

# API Service

## Responsibility

Provides the public interface to DiaperScout.

Every official client, including the PWA, consumes the same API.

Business rules exist within backend services rather than client applications.

The API should evolve through versioning while maintaining compatibility within supported versions.

---

# Background Processing Service

## Responsibility

Executes asynchronous work.

Examples include:

- Image processing
- Search indexing
- Scout Task generation
- Trust recalculation
- Retail confidence recalculation
- Follow-up reminders
- Derived data updates

Background work should be event-driven rather than dependent upon scheduled maintenance windows.

Long-running operations should expose observable progress wherever practical.

---

# Service Communication

Services communicate through well-defined contracts.

Where practical:

- immediate operations should use synchronous requests;
- long-running work should be triggered by events.

Services should remain loosely coupled and communicate through published interfaces rather than implementation details.

---

# Architectural Boundaries

Each service owns a single responsibility.

For example:

- The Observation Service records evidence.
- The Editorial Service evaluates evidence.
- The Atlas Service publishes canonical knowledge.
- The Search Service indexes the Atlas.
- The Scout Service maintains community stewardship.

Maintaining these boundaries keeps the architecture understandable, testable and maintainable.

---

# Evolution

The responsibilities described within this document are expected to remain stable over the lifetime of the project.

Implementation technologies may evolve.

Deployment strategies may evolve.

The Atlas and the responsibilities required to maintain it should not.