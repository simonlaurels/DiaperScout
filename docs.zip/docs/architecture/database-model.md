# Database Model

## Purpose

This document describes how the DiaperScout domain is represented within persistent storage.

It intentionally focuses on the structure of information rather than the implementation details of any particular database technology.

The database exists to preserve the Atlas, the evidence that supports it and the history of how knowledge evolves.

---

# Design Philosophy

The database should model the real world.

Data structures should represent genuine concepts within the domain rather than optimising prematurely for implementation convenience.

The database should favour:

- clarity;
- integrity;
- traceability;
- maintainability;
- long-term evolution.

The schema should be understandable by future contributors.

---

# Separation of Concerns

The database separates information into several distinct categories.

## Atlas

Canonical knowledge presented by DiaperScout.

Examples include:

- Products
- Product Specifications
- Manufacturers
- Product Images
- Regional Variations

Atlas data represents the published Guide.

---

## Observations

Evidence collected from the community.

Examples include:

- Discoveries
- Retail observations
- Correction requests
- Manufacturer submissions

Observations never become canonical knowledge directly.

---

## Evidence

Supporting material attached to observations.

Examples include:

- photographs;
- barcode images;
- official documentation;
- notes.

Evidence belongs to observations rather than products.

---

## Editorial

Records how observations become trusted knowledge.

Examples include:

- moderation decisions;
- review history;
- provenance;
- editorial comments.

---

## Community

Information about contributors.

Examples include:

- users;
- roles;
- trust;
- Scout history;
- moderator activity.

---

## Retail

Information describing the retail world.

Examples include:

- retailers;
- locations;
- countries;
- shipping destinations.

Retail availability is derived from observations rather than stored as mutable state.

---

# Entity Identity

Every entity should possess a permanent immutable identifier.

Identifiers should never change.

Where user-facing identifiers improve readability, they should exist alongside immutable internal identifiers.

Examples include:

- human-readable URLs;
- product slugs;
- manufacturer slugs.

Identifiers exist for computers.

Names exist for people.

---

# Relationships

Relationships should mirror reality.

Examples include:

- manufacturers produce products;
- products possess specifications;
- retailers stock products;
- observations describe products;
- evidence supports observations;
- editorial decisions evaluate observations.

Relationships should remain explicit.

Implicit relationships should be avoided wherever practical.

---

# Historical Preservation

Knowledge evolves.

The database should preserve that evolution wherever it contributes to understanding.

Examples include:

- editorial history;
- previous specifications;
- provenance;
- observation history.

The objective is to preserve the story of the Atlas without cluttering it with insignificant operational events.

---

# Immutability

Observations should be treated as historical records.

Once submitted, observations should normally remain unchanged.

Editorial decisions determine how observations influence the Atlas.

This preserves evidence while allowing the Guide to evolve.

---

# Derived Information

Some information is calculated rather than stored directly.

Examples include:

- retailer confidence;
- Scout recommendations;
- availability summaries;
- stale observation detection.

Derived information should always be reproducible from underlying data.

Where possible, derived values should not become the authoritative source of truth.

---

# Referential Integrity

Relationships between entities should remain valid throughout the lifetime of the Guide.

The architecture should prevent accidental orphaning of important information.

Deleting users, observations or products should not compromise the integrity of historical knowledge.

Where removal is necessary, anonymisation should normally be preferred over destructive deletion.

---

# Schema Evolution

The database should support gradual evolution.

Schema changes should favour expansion before replacement.

Whenever practical:

- introduce new structures;
- migrate data;
- retire obsolete structures later.

This supports continuous deployment while preserving compatibility.

---

# Performance

Performance optimisations should never compromise the integrity of the data model.

When optimisation is required, preference should be given to:

- indexes;
- caching;
- derived views;
- background processing.

The conceptual model should remain stable even if physical storage evolves.

---

# The Database is Not the Atlas

The Atlas is a curated view of the knowledge held by DiaperScout.

The database contains considerably more information than is presented to users.

Examples include:

- evidence;
- editorial history;
- provenance;
- moderation records;
- community observations.

The Atlas is constructed from this information through deterministic editorial processes.

The database therefore represents both the published Atlas and the knowledge from which that Atlas is derived.

---

# Future Evolution

The database model should evolve alongside the domain model.

Changes should strengthen the architecture rather than introducing unnecessary complexity.

The objective is to preserve a database that remains understandable, trustworthy and capable of supporting the Atlas for many years to come.