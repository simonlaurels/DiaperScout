# Deployment & Operations

## Purpose

This document defines the operational principles that keep DiaperScout reliable, maintainable and available.

It intentionally focuses on operational philosophy rather than specific deployment technologies.

The objective is to ensure the Atlas remains trustworthy, resilient and continuously available.

---

# Philosophy

The Atlas is a living body of knowledge.

It should evolve continuously without unnecessary interruption.

Operational decisions should prioritise preserving the Atlas, protecting contributor work and maintaining availability.

The application exists to serve the Atlas.

Operations exist to protect it.

---

# Design Principles

Operations should be:

- reliable;
- observable;
- resilient;
- recoverable;
- maintainable;
- continuously deployable.

Operational complexity should never compromise the integrity of the Atlas.

---

# Continuous Availability

DiaperScout should not depend upon scheduled maintenance windows.

The architecture should support continuous operation.

Users should be able to:

- browse the Atlas;
- submit observations;
- review discoveries;
- perform moderation;

without unnecessary interruption.

Where maintenance is unavoidable, disruption should be minimised.

---

# Continuous Deployment

The architecture should support incremental deployment.

Schema evolution should favour:

- expansion before replacement;
- backwards compatibility where practical;
- gradual migration;
- safe retirement of obsolete structures.

Deployments should become routine rather than exceptional.

---

# Event-Driven Operation

Operational work should occur in response to events.

Examples include:

- search index updates;
- Scout Task generation;
- media processing;
- trust recalculation;
- retailer confidence updates.

The system should react continuously rather than relying upon scheduled maintenance.

---

# Background Processing

Long-running work should execute independently from user requests.

Examples include:

- image optimisation;
- thumbnail generation;
- media validation;
- search indexing;
- derived data generation.

Background work should expose observable progress wherever appropriate.

---

# Monitoring

The architecture should expose meaningful operational information.

Examples include:

- service health;
- workflow progress;
- processing failures;
- queue depth;
- storage utilisation;
- API performance.

Operational monitoring should support rapid diagnosis while remaining independent from application behaviour.

---

# Logging

Operational logs should explain:

- what happened;
- when it happened;
- which service performed the action;
- whether recovery succeeded.

Logs should assist investigation without exposing unnecessary implementation detail.

---

# Failure Recovery

Temporary failures should not result in lost knowledge.

The architecture should support:

- retryable background work;
- resumable workflows;
- graceful degradation;
- recovery after interruption.

Protecting contributor effort should take priority over immediate completion.

---

# Backups

Backups exist to preserve the Atlas.

This includes:

- canonical knowledge;
- observations;
- evidence;
- editorial history;
- provenance;
- media.

The objective is not merely recovering software.

The objective is ensuring the accumulated knowledge of the Atlas can never be unnecessarily lost.

---

# Security

Operational security protects both the platform and the Atlas.

Examples include:

- secure infrastructure;
- protected credentials;
- controlled administrative access;
- audit logging;
- regular maintenance.

Security should reduce risk without unnecessarily restricting contributors.

---

# Scalability

The architecture should scale through clear service boundaries rather than unnecessary complexity.

Scaling should preserve:

- deterministic behaviour;
- editorial integrity;
- API consistency;
- contributor experience.

Growth should not require redesigning the architecture.

---

# Disaster Recovery

Recovery planning should prioritise restoring the Atlas before restoring convenience.

The ability to recover:

- Products;
- Product Specifications;
- Observations;
- Evidence;
- Editorial history;
- Media;

is more important than restoring any individual application instance.

The Atlas remains the primary asset.

---

# Operational Responsibility

Operational responsibilities belong to Administrators.

Editorial responsibilities belong to Moderators.

Maintaining this separation reduces risk and strengthens governance.

---

# Future Evolution

Operational technologies will evolve throughout the lifetime of DiaperScout.

These principles should remain stable regardless of:

- hosting provider;
- programming language;
- database technology;
- deployment platform.

The architecture should continue to support the Atlas for many years while remaining understandable by future contributors.