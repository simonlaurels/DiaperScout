# Editorial Architecture

## Purpose

This document describes how DiaperScout transforms evidence into trusted knowledge.

The editorial architecture exists to protect the integrity of the Atlas.

Rather than allowing contributors to edit canonical knowledge directly, every meaningful change follows a consistent editorial process.

This preserves trust, provenance and the long-term quality of the Guide.

---

# Philosophy

The Atlas is curated.

It is not crowd-edited.

Community contributions improve the Atlas by providing evidence.

Editorial review determines how that evidence influences canonical knowledge.

The objective is not to slow contributions.

The objective is to ensure every published fact is trustworthy.

---

# Editorial Principles

The editorial system should:

- preserve evidence;
- encourage community contribution;
- maintain consistency;
- remain transparent;
- explain its decisions;
- improve the Atlas over time.

The editorial workflow should make correct behaviour easier than incorrect behaviour.

---

# One Editorial Pipeline

All evidence enters the Atlas through a single editorial pipeline.

Sources may include:

- Scout discoveries;
- Retail observations;
- Correction requests;
- Manufacturer submissions;
- Moderator investigations.

The authority of the source influences confidence.

It does not create alternative mechanisms for modifying the Atlas.

---

# Editorial Workflow

Every editorial workflow follows the same broad pattern.

```text
Evidence

↓

Editorial Review

↓

Decision

↓

Atlas Updated

↓

Historical Record Preserved
```

The workflow remains consistent regardless of where evidence originated.

---

# Editorial Decisions

Editorial decisions include:

- Accept
- Reject
- Request additional evidence
- Defer pending investigation

Every decision should be explainable.

Where practical, decisions should reference the evidence supporting them.

---

# Canonical Knowledge

Accepted evidence updates the Atlas.

The Atlas always represents the current editorial understanding.

Previous understanding forms part of the editorial history where appropriate.

The Atlas should remain concise.

The editorial history should remain complete.

---

# Provenance

Every significant piece of canonical knowledge should retain provenance.

The editorial system should always be capable of answering:

- Why is this believed?
- What evidence supports it?
- Who reviewed it?
- When was it accepted?
- What did it replace?

Trust depends upon explainability.

---

# Editorial History

The editorial history represents the evolution of the Atlas.

It is comparable to annotations within a Scout's Atlas.

History should explain meaningful changes.

It should not become cluttered with insignificant operational mistakes.

For example:

- accepted corrections;
- specification revisions;
- manufacturer updates;

should remain visible.

Accidental moderator actions corrected immediately through an undo mechanism should not become part of the permanent editorial record.

---

# Manufacturer Evidence

Verified manufacturers contribute through the same editorial pipeline as every other contributor.

Manufacturer observations represent highly authoritative evidence.

They do not bypass editorial review.

This preserves consistency across the architecture.

---

# Community Corrections

Community members may challenge existing Atlas knowledge.

Correction requests become editorial work rather than immediately changing canonical information.

The objective is continual refinement rather than unrestricted editing.

---

# Moderators

Moderators curate the Atlas.

Their responsibilities include:

- evaluating evidence;
- reviewing discoveries;
- resolving correction requests;
- maintaining editorial consistency;
- protecting the integrity of the Guide.

Moderators should explain significant editorial decisions where appropriate.

---

# Moderator Recommendations

Moderators are not automatically appointed.

The system may recommend trusted contributors for promotion based upon:

- sustained high trust;
- consistently valuable contributions;
- demonstrated stewardship of the Atlas.

Promotion remains a human decision.

Responsibility is earned rather than granted automatically.

---

# Scout Relationship

The editorial system depends upon the Scout community.

Scouts explore the world.

Editors curate the resulting knowledge.

These responsibilities are complementary rather than hierarchical.

The quality of the Atlas depends upon both.

---

# Transparency

Editorial decisions should be understandable.

Where appropriate, contributors should be able to understand:

- the status of their submissions;
- why evidence was accepted;
- why evidence was rejected;
- what additional information is required.

Transparency strengthens trust in both the Atlas and the editorial process.

---

# Evolution

The editorial architecture should evolve alongside the Atlas.

Future workflows should preserve the same core principles:

- evidence before publication;
- consistent editorial review;
- explainable decisions;
- preserved provenance;
- long-term trust.

The objective is not simply to publish information.

The objective is to build a trustworthy Atlas whose knowledge can always explain itself.