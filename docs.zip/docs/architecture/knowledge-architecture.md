# Knowledge Architecture

## Purpose

This document describes how knowledge enters, evolves and becomes part of the DiaperScout Guide.

Rather than treating the Guide as a collection of editable database records, DiaperScout models knowledge as evidence that is curated into a trustworthy Atlas.

Understanding this distinction is fundamental to understanding the architecture of the project.

---

# The Atlas

The Guide is the published Atlas.

It represents DiaperScout's current understanding of the world.

Users browse the Atlas.

Search indexes the Atlas.

APIs primarily expose the Atlas.

The Atlas should always present the current canonical understanding of products and their characteristics.

---

# Evidence

Knowledge begins as evidence.

Evidence may originate from many sources, including:

- Product discoveries
- Retailer observations
- Manufacturer submissions
- Correction requests
- Moderator investigations

Evidence is not immediately considered canonical.

Instead, it becomes input into the editorial process.

---

# Observations

Observations record things that someone has witnessed.

Examples include:

- discovering a previously unknown product;
- observing a product at a retailer;
- scanning a barcode;
- recording a retail price;
- submitting photographs;
- reporting a potential correction.

Observations describe events.

They do not directly modify the Guide.

---

# Sources

Not all evidence has equal authority.

Examples include:

- Community Scouts
- Trusted Scouts
- Moderators
- Verified Manufacturers

Authority influences editorial confidence.

It does not create alternative pathways into the Guide.

Every source contributes evidence through the same editorial model.

---

# Editorial Decisions

Editors evaluate evidence.

Possible outcomes include:

- accept;
- reject;
- request additional evidence;
- defer pending investigation.

Editorial decisions determine whether evidence becomes part of the Guide.

---

# Canonical Knowledge

Once accepted, knowledge becomes part of the Atlas.

Canonical knowledge should represent the best current understanding available.

Examples include:

- Product Specifications
- Manufacturer information
- Product imagery
- Regional variations

Canonical knowledge is intended for public consumption.

---

# Provenance

Every significant piece of canonical knowledge should retain traceable provenance.

The architecture should always be capable of explaining:

- where information originated;
- what evidence supported it;
- who reviewed it;
- when it entered the Guide.

Trust depends upon explainability.

---

# Historical Record

The Atlas represents the current understanding.

The historical record explains how that understanding evolved.

Editorial history should be preserved wherever it contributes to understanding the evolution of the Guide.

The historical record is comparable to annotations within a Scout's Atlas.

Earlier knowledge is not erased without reason.

Instead, the evolution of knowledge remains understandable.

---

# Derived Knowledge

Some information presented within the Guide is derived rather than entered directly.

Examples include:

- retailer confidence;
- Scout task generation;
- stale observation detection;
- availability summaries.

Derived knowledge should always be reproducible from the underlying evidence.

Where derived knowledge changes, the supporting evidence remains unchanged.

---

# Continuous Refinement

The Guide is never considered complete.

New evidence continually improves understanding.

The architecture should therefore support continuous refinement while preserving trust, provenance and editorial integrity.

Knowledge is expected to evolve.

The process by which it evolves should remain consistent.

---

# Knowledge Lifecycle

Knowledge within DiaperScout follows a consistent lifecycle.

```text
Observation

↓

Evidence

↓

Editorial Review

↓

Canonical Guide

↓

Future Evidence

↓

Refined Guide
```

The Guide is therefore not a database that users edit directly.

It is the curated result of an ongoing process of exploration, verification and refinement.

---

# Architectural Consequences

This model has several important consequences.

- Products remain independent of observations.
- Images belong to either products or observations depending on their purpose.
- Retail availability is built from observations rather than mutable state.
- Manufacturer submissions are treated as evidence rather than direct edits.
- Search indexes canonical knowledge rather than raw observations.
- APIs expose both canonical knowledge and supporting evidence where appropriate.

Every architectural subsystem should reinforce this model rather than bypass it.