# Scout Task System

## Purpose

This document describes how DiaperScout generates, manages and completes Scout Tasks.

Scout Tasks help maintain the quality of the Atlas by directing community effort towards areas where additional evidence is most valuable.

Rather than relying upon contributors to decide what to investigate, the Atlas actively identifies where exploration is needed.

---

# Philosophy

Scouts are explorers.

They are also stewards of the Atlas.

The purpose of Scout Tasks is not to create activity.

The purpose is to improve the quality, freshness and trustworthiness of the Guide.

Every Scout Task should answer a genuine question that the Atlas cannot currently answer with confidence.

---

# Guiding Principles

Scout Tasks should:

- strengthen the Atlas;
- encourage meaningful exploration;
- improve confidence;
- avoid unnecessary duplication;
- prioritise evidence over activity.

The objective is quality rather than quantity.

---

# How Tasks are Created

Scout Tasks are generated automatically from the current state of the Atlas.

Tasks are created when additional evidence would improve the Guide.

The architecture should continuously evaluate opportunities to improve the Atlas.

---

# Task Categories

## Availability Confirmation

The Atlas has not received a retailer observation for an extended period.

Example:

> BetterDry M10
>
> Tesco Yate
>
> Last confirmed 94 days ago.

Scout Task:

> Confirm whether this product is still available.

---

## New Product Discovery

An unknown barcode has been submitted.

Scout Task:

> Help discover this product.

---

## Conflicting Evidence

Different observations suggest conflicting conclusions.

Examples include:

- conflicting retailer observations;
- differing community evidence;
- manufacturer clarification required.

Scout Task:

> Gather additional evidence.

---

## Correction Investigation

A correction request requires further verification.

Scout Task:

> Investigate the reported discrepancy.

---

## Regional Verification

A product appears to vary between markets.

Scout Task:

> Confirm regional variation.

---

# Prioritisation

Not every task has equal value.

The system should prioritise tasks that most improve the Atlas.

Examples include:

- unresolved discoveries;
- conflicting evidence;
- stale retailer information;
- incomplete Product Specifications.

Tasks should encourage contributors towards the greatest benefit for the community.

---

# Geographic Awareness

Where appropriate, Scout Tasks should be geographically relevant.

Examples include:

- nearby retailers;
- local product confirmations;
- regional investigations.

Scouts should normally receive opportunities they are realistically able to complete.

---

# Task Completion

Completing a Scout Task generates a new Observation.

The Observation enters the standard editorial workflow.

Scout Tasks do not directly modify the Atlas.

The architecture remains consistent:

Observation

↓

Evidence

↓

Editorial Review

↓

Atlas Updated

---

# Expiration

Scout Tasks should expire naturally when they are no longer relevant.

Examples include:

- another Scout has already completed the task;
- newer evidence resolves the uncertainty;
- editorial review determines further investigation is unnecessary.

The task system should avoid wasting community effort.

---

# Duplicate Prevention

Multiple identical tasks should be avoided.

The architecture should identify when multiple uncertainties are addressed by the same investigation.

This reduces unnecessary work while improving contributor experience.

---

# Trust

Successfully completing Scout Tasks contributes positively towards community trust.

The quality of submitted evidence is more important than the number of completed tasks.

The system should reward stewardship rather than activity alone.

---

# Transparency

Scouts should understand why a task exists.

Examples include:

- Last retailer confirmation 97 days ago.
- Product discovered but awaiting additional evidence.
- Conflicting retailer observations.
- Manufacturer clarification requested.

Understanding the reason behind a task improves both trust and motivation.

---

# Atlas Maintenance

Scout Tasks allow the Atlas to maintain itself through community exploration.

Rather than assuming outdated information remains correct, the Atlas actively requests fresh evidence.

This keeps knowledge current without relying upon arbitrary expiry dates.

---

# Evolution

As DiaperScout evolves, new categories of Scout Task may emerge.

Every task should continue to satisfy one simple principle:

The task should improve the Atlas.

Tasks should never exist simply to generate community activity.

They exist because the Atlas genuinely benefits from the additional evidence.