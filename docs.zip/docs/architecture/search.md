# Search

## Purpose

This document describes how users discover products within the DiaperScout Atlas.

Search exists to help people explore trustworthy knowledge.

It should remain deterministic, predictable and understandable.

Search should explain the Atlas rather than attempting to interpret user intent through artificial intelligence.

---

# Philosophy

DiaperScout is an Explorer's Guide.

Search should therefore help users navigate the Guide rather than guess what they meant.

Where structured knowledge exists, it should always be preferred over inference.

---

# Design Principles

Search should be:

- deterministic;
- explainable;
- fast;
- predictable;
- based upon canonical knowledge.

Every search result should be reproducible using the same input.

---

# Canonical Data Only

Search indexes the Atlas.

It does not directly index:

- observations;
- pending discoveries;
- moderation queues;
- rejected submissions.

Users should search the published Guide rather than the evidence used to construct it.

---

# Product Search

Free-text search is intentionally limited.

Free-text search applies to:

- Product Name

The objective is to quickly locate known products.

Free-text search should not attempt to interpret arbitrary descriptions.

---

# Structured Filtering

Most exploration occurs through structured filters.

Examples include:

- Manufacturer
- Size
- Backing
- Fastening System
- Wetness Indicator
- Absorbency
- Colour
- Print
- Availability
- Country

Structured filters provide deterministic exploration without ambiguity.

---

# Barcode Search

Barcode scanning is a first-class entry point into the Atlas.

Scanning a recognised barcode should immediately locate the corresponding Product.

Barcode search should not require free-text interpretation.

---

# Discovery Workflow

Scanning an unknown barcode initiates the product discovery workflow.

The search system therefore acts as both:

- a retrieval mechanism;
- a gateway into community contribution.

---

# Retail Exploration

Retail information should be searchable independently from Product information.

Users should be able to answer questions such as:

- Which retailers currently stock this product?
- Which products are available at this retailer?
- Which products have recently been confirmed nearby?

Retail search should remain based upon community observations interpreted by the Atlas.

---

# Availability

Retail availability should represent the Atlas' current understanding.

Availability should not imply live stock information.

Instead, it reflects the most recent trusted observations.

Where confidence decreases over time, search results should reflect that uncertainty.

---

# Geographic Search

Geographic search should support exploration based upon location.

Examples include:

- nearby retailers;
- products confirmed nearby;
- country-specific availability.

Location assists exploration.

It should not replace structured search.

---

# Scout Missions

Search also supports maintaining the Atlas.

Examples include:

- products not confirmed recently;
- retailers requiring verification;
- conflicting observations;
- unresolved correction requests.

These searches generate Scout Tasks that help keep the Atlas current.

---

# Performance

Search should remain responsive regardless of Atlas size.

Performance improvements should not alter search behaviour.

Examples include:

- indexing;
- caching;
- background index updates.

Implementation details should remain invisible to users.

---

# Artificial Intelligence

Artificial intelligence is not required for search.

The Atlas contains structured knowledge.

Search should therefore rely upon deterministic indexing and structured filtering rather than probabilistic interpretation.

This improves explainability, reproducibility and long-term maintainability.

---

# Evolution

Search should evolve alongside the Atlas.

As additional structured knowledge becomes available, exploration should increasingly favour deterministic filters over increasingly complex free-text search.

The objective is to make discovering trustworthy knowledge simple, transparent and predictable.