# Workflow Architecture

## Purpose

This document describes how work flows through DiaperScout.

Unlike the Atlas, which represents published knowledge, workflows describe how knowledge moves from community observation to trusted publication.

Workflows also govern long-running operations, background processing and community stewardship.

The objective is to ensure every significant action follows a consistent, understandable lifecycle.

---

# Philosophy

DiaperScout is built around workflows rather than transactions.

Most meaningful actions do not immediately change the Atlas.

Instead, they begin a journey.

Examples include:

- discovering a product;
- reporting retailer availability;
- requesting a correction;
- submitting manufacturer information.

Each workflow preserves evidence, exposes progress and ultimately results in an editorial decision.

---

# Design Principles

Workflows should be:

- observable;
- deterministic;
- resilient;
- recoverable;
- event-driven;
- understandable.

Users should always understand where their contribution is within the workflow.

---

# Workflow Lifecycle

Every workflow follows a common lifecycle.

```text
Submitted

↓

Validated

↓

Processing

↓

Editorial Review

↓

Published

or

Rejected
```

Individual workflows may introduce additional stages where required.

---

# Event-Driven Processing

Workflows progress through events rather than scheduled maintenance.

Examples include:

- observation submitted;
- barcode recognised;
- images processed;
- editorial decision recorded;
- Atlas updated;
- search index refreshed.

Services react to events as they occur.

The architecture should not depend upon scheduled maintenance windows.

---

# Long-Running Operations

Some operations require background processing.

Examples include:

- media processing;
- large uploads;
- search indexing;
- trust recalculation;
- Scout Task generation.

These operations should continue independently of the user's session.

---

# Progress Reporting

Long-running workflows should expose meaningful progress.

Examples include:

- ✓ Submission received
- ✓ Images uploaded
- ✓ Barcode recognised
- ✓ Ready for moderation
- ⏳ Under editorial review
- ✓ Published

Progress should reflect user-understandable milestones rather than internal implementation details.

---

# Discovery Workflow

The discovery workflow begins when an unknown product is submitted.

Typical stages include:

- observation recorded;
- evidence validated;
- media processed;
- editorial review;
- Product created;
- Atlas published.

The contributor should always be able to understand the current status of the discovery.

---

# Retail Observation Workflow

Retail observations contribute evidence about product availability.

The workflow records:

- retailer;
- location;
- timestamp;
- optional price;
- supporting evidence.

Accepted observations contribute to the Atlas' understanding of retailer availability.

---

# Correction Workflow

Correction requests challenge existing Atlas knowledge.

Rather than modifying canonical information directly, they enter editorial review.

Possible outcomes include:

- accepted;
- rejected;
- additional evidence requested.

The workflow preserves both the challenge and its outcome.

---

# Manufacturer Workflow

Verified manufacturers contribute through the same architectural workflow as every other contributor.

Manufacturer submissions represent highly authoritative evidence.

They do not bypass editorial review.

This preserves a single consistent pathway into the Atlas.

---

# Scout Task Workflow

The Atlas continuously identifies areas requiring further exploration.

Examples include:

- retailer information becoming stale;
- conflicting observations;
- products requiring confirmation;
- correction requests awaiting investigation.

These become Scout Tasks.

Completed Scout Tasks generate new observations, continuing the cycle of refinement.

---

# Failure Recovery

Workflows should be resilient.

Temporary failures should not result in lost contributions.

Background processing should retry work where appropriate.

Contributors should be informed when additional action is genuinely required.

---

# Offline Support

The Progressive Web App should support temporary loss of connectivity.

Where practical:

- observations should be stored locally;
- uploads should resume automatically;
- workflows should continue once connectivity returns.

Users should not be required to repeat completed work.

---

# Workflow History

Significant workflow milestones should remain visible to contributors.

Examples include:

- submission received;
- moderation started;
- evidence requested;
- accepted;
- rejected.

This provides transparency while avoiding unnecessary technical detail.

---

# Evolution

New workflows should follow the same architectural principles.

Every workflow should:

- begin with evidence;
- preserve user confidence;
- expose meaningful progress;
- conclude with a clear outcome.

Consistency across workflows strengthens both the architecture and the contributor experience.